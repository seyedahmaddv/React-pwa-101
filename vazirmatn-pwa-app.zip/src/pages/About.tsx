export default function About() {
  return <h1>درباره ما</h1>;
}
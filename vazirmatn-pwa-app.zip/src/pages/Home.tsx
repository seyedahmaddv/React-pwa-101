export default function Home() {
  return <h1>صفحه اصلی</h1>;
}